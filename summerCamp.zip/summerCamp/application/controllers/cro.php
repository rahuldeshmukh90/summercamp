<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Cro extends Main {

  public $loginToken=0;

  function __construct()
  {
        parent::__construct('cro');
        $this->loginToken = $this->session->userdata("tokenid");
  }

	public function index()
	{
     if($this->session->userdata("role")=="cro"){
           //echo "NO PAGE AVAILABLE"; die;
           $this->load->view('cro/index');

      }else{
        //echo "ERROR"; die;
        $this->load->view('home/login');
        
      }

		
	}

 /*********FOR ATTENDANCE VIEW*********************/
 
 public function traineeAttendance(){

  $this->load->view('cro/attendance');
}

/******************GET ALL TRAINEE (FOR REGISTER IN ACTIVITY )*************************/
 public function getTaineeList(){
    
       $data = array(
                      "activityId"  => (int)$this->input->post('activityId'),
                      "phaseId"     => (int)$this->input->post('phaseId'),
                      "locationId"  => (int)$this->input->post('locationId')
                    );

        $data_string = json_encode($data);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/trainer/listForAttendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );

        $result = curl_exec($ch);
        curl_close($ch);
        echo $result; die();   
    } 

    /******************Take Attendace (FOR TRAINEE )*************************/

    public function takeAttendanceByajax(){
  
 
        $taineeId   = $this->input->post('taineeId');
        $eventId    = $this->input->post('eventId');

       if (!empty($taineeId) && !empty($eventId)){
        
        $data  = array(
                        "eventId"  => (int)$eventId,
                        "trainerIds" => array((int)$taineeId)
                      );
        
        $data_string = json_encode($data);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/trainer/markAttendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        
        echo $result1; die();
        
        }else{

          redirect(site_url('cro/traineeAttendance'));  
        }    
        
    }  

    /***********take multiple attendace*****************/
    
    function multipleattendaceUpdate(){

     $eventId   = $this->input->post('eventId');

     $trainerIds = $this->input->post('attendance');
 
        $numArray = array_map('intval', $trainerIds);

        $info = array(
                      'eventId'      => (int)$eventId,
                      'trainerIds'   => $numArray 
                       );
 
        $data_string = json_encode($info);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/trainer/markAttendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        echo $result1;
        die();
       

        
     }  
	
}	