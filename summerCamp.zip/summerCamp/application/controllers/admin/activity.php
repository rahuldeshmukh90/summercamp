<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//require_once('main.php');

class Activity extends CI_Controller {

	public function index()
	{
		$this->load->view('admin/list');

	}

	function getphaselist(){
        
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/phase/list");
       // curl_setopt($ch, CURLOPT_POST, 0);
       // curl_setopt($ch, CURLOPT_POSTFIELDS);  //Post Fields
	      curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
		    curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $data['phaselist'] =   json_decode($server_output);

        $this->load->view('admin/list' ,$data);
	}

  public function addphase(){
  
        $from = $this->input->post('from');
        $to   = $this->input->post('to'); 

        $data  = array(
                      
                      "eventId"  => $from,
                      "studentIds" => $to
                    );


        $data_string = json_encode($data);
        
        print_r($data_string); die();

        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/attendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken: uevlba8ah4bnke45p01scahmt4ib02n5')
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);

        //execute post
        $result1 = curl_exec($ch);

        
        $result = json_decode($result1);
        curl_close($ch);
        if($result->result) {

          $data['msg_success'] = $result->message;
            $this->load->view('student/attendence',$data);
        }else{

            $data['msg_success'] = "error";
            $this->load->view('student/attendence'); 
        }

        
        
  }
}	