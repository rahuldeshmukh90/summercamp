<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once('main.php');
// Code written by TangleSkills

class Multipleqrcode extends Main {
    
    public $loginToken=0;
    public $loginRole=0;

	public function __construct()
    {
        parent::__construct('multipleqrcode');
		$this->load->helper('url');
		$this->loginRole = $this->session->userdata("role");

    }
	
	public function get_file_dir() {
	    global $argv;
	    $dir = dirname(getcwd() . '/' . $argv[0]);
	    $curDir = getcwd();
	    chdir($dir);
	    $dir = getcwd();
	    chdir($curDir);
	    return $dir; 
	}

	public function index()
 	{

    if($this->loginRole=="cro"){
        
        $files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
        foreach($files as $file){ // iterate files
		  if(is_file($file))
		    unlink($file); // delete file
		} 
      	if (($this->input->post('trainerIds')) && ($this->input->post('eventId'))) {

	        $trainerIds           = $this->input->post('trainerIds'); 
			$eventId              = $this->input->post('eventId');
			
 
			$data['img_url'] = "";
            $i=0;
		
		foreach ($trainerIds as $row1) {

			// if($this->input->post('action') && $this->input->post('action') == "generate_qrcode")
			// {
			   $data2 = array(

		                        'eventId'=>$eventId,
			                    'trainerIds'=>array((int)$row1)
		                     );        
 	
				$this->load->library('ciqrcode');
				$qr_image=rand().'.png';
				$params['data'] = json_encode($data2);
				$params['level'] = 'H';
				$params['size'] = 8;
				$params['savename'] =FCPATH."uploads/qr_image/".$qr_image;
				if($this->ciqrcode->generate($params))
				{
				    $data['img_url']=$qr_image;	
					$data['studinfo'][$i] = array( 

						              'img_url'      => $qr_image,
                                      'trainerIds'   => $row1,
                                      'eventId'      => $eventId
                                   );
				}
				 $i++;
		}
            
           $this->load->view('cro/multipleqrcode',$data);
	}else{

	      echo"There is Some Problem, Please Try after some time";
	}	
    }elseif($this->loginRole=="teacher"){

    	    $files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
	        foreach($files as $file){ // iterate files
			  if(is_file($file))
			    unlink($file); // delete file
			} 
		    if (($this->input->post('studentIds')) && ($this->input->post('activityId'))) {

			                $studentIds           = $this->input->post('studentIds'); 
					$activityId           = $this->input->post('activityId');
					$activityName         = $this->input->post('activityName');
		 
					$data['img_url'] = "";
		           $i=0;
				
				foreach ($studentIds as $row1) {

					// if($this->input->post('action') && $this->input->post('action') == "generate_qrcode")
					// {
					   $data2 = array(

				                        'eventId'=>$activityId,
					                    'studentIds'=>array((int)$row1)
				                     );        
		 	
						$this->load->library('ciqrcode');
						$qr_image=rand().'.png';
						$params['data'] = json_encode($data2);
						$params['level'] = 'H';
						$params['size'] = 8;
						$params['savename'] =FCPATH."uploads/qr_image/".$qr_image;
						if($this->ciqrcode->generate($params))
						{
						    $data['img_url']=$qr_image;	
							$data['studinfo'][$i] = array( 

								              'img_url'      => $qr_image,
		                                      'studentIds'   => $row1,
		                                      'activityId'   => $activityId,
		                                      'activityName' => $activityName
							               );
						}
						 $i++;
				}
		            
		           $this->load->view('multipleqrcode',$data);
			}else{

			      echo"There is Some Problem, Please Try after some time";
			}

    }elseif($this->loginRole=="admin") {

    	    $files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
	        foreach($files as $file){ // iterate files
			  if(is_file($file))
			    unlink($file); // delete file
			}
    	   if (($this->input->post('tech_id')) ) {

			        $teacherId  = $this->input->post('tech_id');
			        $name       = $this->input->post('name');
			        $gender     = $this->input->post('gender');
			        $phoneNo    = $this->input->post('phoneNo');
			        $subject    = $this->input->post('subject');
			        $schoolName = $this->input->post('schoolName');

					$data['img_url'] = "";
		            $i=0;
				
				foreach ($teacherId as $row1) {

					  

					   $data2 = array( 'teacherId' =>array($row1) );        
		 	
		 	            $this->load->library('ciqrcode');
						$qr_image=rand().'.png';
						$params['data'] = json_encode($data2);
						$params['level'] = 'H';
						$params['size'] = 8;
						$params['savename'] =FCPATH."uploads/qr_image/".$qr_image;
						if($this->ciqrcode->generate($params))
						{
						    $data['img_url']=$qr_image;	
							$data['teacherInfo'][$i] = array( 

								              'img_url'      => $qr_image,
		                                      'teacherId'   => $row1
		                                      
							               );
						}
						 $i++;
				}
		            
		           $this->load->view('admin/teacher/multipleQrCode',$data);
			}else{

			      echo"There is Some Problem, Please Try after some time";
			} 

    } 

	
	}
}	

