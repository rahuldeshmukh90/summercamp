<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Admin extends main {

    private $loginToken=0;

    function __construct()
    {
        parent::__construct('admin');
        $this->loginToken = $this->session->userdata("tokenid");
    }

	public function index()
      {
         if($this->session->userdata("role")=="admin"){
               
              $this->load->view('admin/dashboard');

          }else{

               $this->load->view('home/page-login');
            
          }
    }
/****************GET ALL PHASE LIST*************************/

	function getphaselist(){
        
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/phase/list");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
		curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        $data['phaselist'] =   json_decode($server_output);
        $this->load->view('admin/phase/list' ,$data);
	}

/***************ADD PHASE TO LIST****************************/

      function addPhase(){
  
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){

        $from = $this->input->post('from');
        $to   = $this->input->post('to');  

        $data  = array( "from" => $from, "to" => $to );
        $data_string = json_encode($data);
        
        //print_r($data_string); 

        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/phase/add');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        //execute post
        $result1 = curl_exec($ch);

        //echo $result1; 
        $result = json_decode($result1);
        curl_close($ch);
        //print_r($result); die();
        if($result->result) {

              $data['msg_success'] = $result->message;
              $this->session->set_flashdata('success', 'Add Phase Successfully.'); 
            // $this->load->view('admin/phase/list',$data);
            redirect('admin/getphaselist');
        }else{

            $data['msg_success'] = "error";
            $this->load->view('admin/phase/list',$data);
        }

    }else{

       $this->load->view('admin/phase/add');

    }    
        
  }
/***********************GET ALL LOCATION LIST**********************/
    
    function getlocationList(){

        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/location/list");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $data['location'] =   json_decode($server_output);

        $this->load->view('admin/location/list' ,$data); 
    }
/********************ADD LOCATION************************/

     function addLocation(){
  
        
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $location = $this->input->post('location');
        if(!empty($location)){
        $data  = array( "location" => $location );
        $data_string = json_encode($data);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/location/add');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        if($result->result){

              
              $this->session->set_flashdata('success', 'Add Location Successfully.'); 
              redirect('admin/getLocationlist');
        }else{

              $this->session->set_flashdata('error', 'Location is not added.'); 
              redirect('admin/getLocationlist');
        }

    }else{
             
            redirect('admin/addLocation');
    }
    }else{

       $this->load->view('admin/location/add');

    }    
        
  }    

/*****************GET ALL RCO LIST************************/

    function getRCOList(){
        
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/rco/list");
       // curl_setopt($ch, CURLOPT_POST, 0);
       // curl_setopt($ch, CURLOPT_POSTFIELDS);  //Post Fields
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken    
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $data['rco'] =   json_decode($server_output);

        $this->load->view('admin/rco/list' ,$data); 
    }

    /*****************FOR ADD NEW EVENT***********************/

    function addEvent(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
              
            $activityId  = $this->input->post('activityId');
            $phaseId     = $this->input->post('phaseId');
            $locationId  = $this->input->post('locationId');
            $rcoId       = $this->input->post('rcoId');
            //$rcoApproval = $this->input->post('rcoApproval');

            if ($activityId && $phaseId && $locationId){
                
                    if(!empty($rcoId)){

                            $data  = array(
                                            "activityId"  => $activityId,
                                            "phaseId"     => $phaseId,
                                            "locationId"  => $locationId,
                                            "rcoApproval" => true,
                                            "rcoId"       => $rcoId
                                          );
                    }else{
                            $data  = array(
                                            
                                            "activityId"  => $activityId,
                                            "phaseId"     => $phaseId,
                                            "locationId"  => $locationId,
                                            "rcoApproval" => false,
                                            
                                          );

                    }
                     
                    $data_string = json_encode($data);
                    $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/add');
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'loginToken:'.$this->loginToken)
                    );
                    $result1  = curl_exec($ch);
                    $result   = json_decode($result1);
                    curl_close($ch);
                    if($result->result){
                        
                        $this->session->set_flashdata('success', $result->message); 
                        redirect('admin/addEvent');
                    }else{

                        $this->session->set_flashdata('error', $result->message); 
                        redirect('admin/addEvent');
                    }

              }else{

                $this->load->view('admin/event/add');
              } 

        }else{
                $this->load->view('admin/event/add');
        } 
    }

/****************REPORT LIST********************************/

    function reportlist(){

        $date = "";

        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/get");
       // curl_setopt($ch, CURLOPT_POST, 0);
       // curl_setopt($ch, CURLOPT_POSTFIELDS);  //Post Fields
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken,
            'date:'.$date    
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $data['reportlist'] =   json_decode($server_output);

        $this->load->view('admin/report/list' ,$data);
    }    

/*************GET DETAIL OF REPORT LIST****************************/

    function getdetailreportlist(){

        $eventId = '14/28-03-2018';

        $eventId1 = $this->uri->segment(3);
        $eventId2 = $this->uri->segment(4);
        $murg_eventId = $eventId1.'/'.$eventId2;

        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/getList");
        
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken,
            'eventId:'.$murg_eventId    
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

       //print_r($server_output); die;
        curl_close ($ch);

        $data['report_detail'] =   json_decode($server_output);

        $this->load->view('admin/report/list_detail' ,$data);
    }
/********************search for report**********************/
  
  function search_report(){
        
        
        $date=date_create($this->input->post('search_report'));
        $date_format = date_format($date,"d-m-Y");

        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/get");
       // curl_setopt($ch, CURLOPT_POST, 0);
       // curl_setopt($ch, CURLOPT_POSTFIELDS);  //Post Fields
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken,
            'date:'.$date_format    
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $data['reportlist'] =   json_decode($server_output);

        $this->load->view('admin/report/list' ,$data);

  }

  /*********************Report for activity registration****************/
  
  function ActivityRegistrationReport(){

    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        if ($this->input->post('locationId')) {
        if($this->input->post('filter')=='location') {
            
            $filter   = $this->input->post('filter');   
            $location = $this->input->post('locationId');    
            //$location = 1;    

            $data = array('filter' => $filter, 'locationId' => $location );
            $data_string = json_encode($data);
            $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/registration');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'loginToken:'.$this->loginToken)
            );
            $result1  = curl_exec($ch);
            $result   = json_decode($result1);
            curl_close($ch);
            if($result->result){
                
                $data['reportlist']  = $result;
                //$data['msg_success'] = $result->message;
                $this->session->set_flashdata('success', $result->message); 
                $this->load->view('admin/report/activity_registration' ,$data);

            }else{

                $data['msg_success'] = $result->message;
                $this->session->set_flashdata('error', $result->message); 
                $this->load->view('admin/report/activity_registration' ,$data);
            }

        }elseif($this->input->post('filter')=='activity'){
            
            $filter     = $this->input->post('filter');   
            $activityId = $this->input->post('activityId');
            $phaseId    = $this->input->post('phaseId');
            $locationId = $this->input->post('locationId');
            
            $data = array('filter' => $filter, 'activityId' => $activityId, 'phaseId' => $phaseId, 'locationId' => $locationId );
            
             $data_string = json_encode($data);
            $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/registration');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'loginToken:'.$this->loginToken)
            );
            $result1  = curl_exec($ch);
            $result   = json_decode($result1);
            curl_close($ch);
            if($result->result){
                
                $data['reportlist']  = $result;
                //$data['msg_success'] = $result->message;
                $this->session->set_flashdata('success', $result->message); 
                $this->load->view('admin/report/activity_registration' ,$data);

            }else{

                $data['msg_success'] = $result->message;
                $this->session->set_flashdata('error', $result->message); 
                $this->load->view('admin/report/activity_registration' ,$data);
            }

        }
       }else{
        //echo "sdf"; die;
               $this->load->view('admin/report/activity_registration');             
       } 
        
    }else{
        $this->load->view('admin/report/activity_registration');     
    }
  }

  /************ADD SCHOOL FOR ADMIN*********************/

  function add_school(){
       
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $name          = $this->input->post('name'); 
            $principalName = $this->input->post('principalName'); 
            $society       = $this->input->post('society'); 
            $code          = $this->input->post('code'); 
            $type          = $this->input->post('type'); 
            $username      = $this->input->post('username'); 
            $password      = $this->input->post('password'); 
            $address       = $this->input->post('address'); 
            $country       = $this->input->post('country'); 
            $state         = $this->input->post('state'); 
            $district      = $this->input->post('district'); 
            
            $full_Address  = array(
                                    'address'  => $address,
                                    'district' => $country,
                                    'state'    => $state,
                                    'country'  => $district   
                                  );
            $addschool = array( 
                                'name'      => $name,
                                'principal' => $principalName,
                                'society'   => $society,
                                'code'      => $code,
                                'type'      => $type,
                                'userName'  => $username,
                                'address'   => $full_Address,
                                'password'  => $password
                                
                              );
            
            $json = json_encode($addschool);
            //print_r($json); 
            $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/school/add');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'loginToken:'.$this->loginToken)
            );
            $encode_result  = curl_exec($ch);
            $result         = json_decode($encode_result);
            //print_r($result); die;
            curl_close($ch);
            if ($result->result){
               
               $this->session->set_flashdata('success', $result->message); 
               redirect('admin/add_school');

            }else{

               $this->session->set_flashdata('error', $result->message);   
               redirect('admin/add_school');
            } 


        }else{

          $this->load->view('admin/school/add');
        }
        
  }

  /*******************Generate report all data*************/
    function compress_report(){
       
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/schoolRegistrationCountPerActivity");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken    
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        $data['compress_data'] = json_decode($server_output);
        $this->load->view('admin/compress_report/list' ,$data);
    } 

  /*************ADD VENDOR ( FOR ADMIN )****************/

  function add_vendor(){
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $userName      = $this->input->post('userName'); 
            $companyName   = $this->input->post('companyName'); 
            $emailId       = $this->input->post('emailId'); 
            $phoneNo       = $this->input->post('phoneNo'); 
            $activityId    = $this->input->post('activityId'); 
            $password      = $this->input->post('password'); 
            $address       = $this->input->post('address'); 
            $country       = $this->input->post('country'); 
            $state         = $this->input->post('state'); 
            $district      = $this->input->post('district'); 

            $numArray = array_map('intval', $activityId);

            $full_Address  = array(
                                    'address'  => $address,
                                    'district' => $country,
                                    'state'    => $state,
                                    'country'  => $district   
                                  );
            $addschool = array( 
                                'companyName' => $companyName,
                                'userName'    => $userName,
                                'emailId'     => $emailId,
                                'activityIds' => $numArray,
                                'phoneNo'     => $phoneNo,
                                'address'     => $full_Address,
                                'password'    => $password
                                
                              );
            $json = json_encode($addschool);
            $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/vendor/add');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'loginToken:'.$this->loginToken)
            );
            $encode_result  = curl_exec($ch);
            $result         = json_decode($encode_result);
            curl_close($ch);
            if ($result->result){
               
               $this->session->set_flashdata('success', $result->message); 
               redirect('admin/add_vendor');

            }else{

               $this->session->set_flashdata('error', $result->message);   
               redirect('admin/add_vendor');
            }

    }else{
        $this->load->view('admin/vendor/add');        
    }

        
  }

  /*************ADD CRO & RCO ( FOR ADMIN )***********/  

  function add_cro(){


        $this->load->view('admin/rco/add');
  }

  /*************ADD SECRETARY ( FOR ADMIN ) **************/

  function add_secretary(){
       
       $this->load->view('admin/secretary/add');
  }

  /***************GET ALL LOGIN USER DETAIL**************/

  function alluserAccessDetail(){

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $name          = $this->input->post('filter_user'); 
            $schoolId      = $this->input->post('school'); 
            if($name){ $category = $this->input->post('filter_user'); }
            if($schoolId){ $id = $this->input->post('school'); }else{ $id = 0; }
            $data   = array( 'category'  => $category,'id' => $id );
            $json = json_encode($data);
            $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/loginDetails');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'loginToken:'.$this->loginToken)
            );
            $encode_result  = curl_exec($ch);
            $result         = json_decode($encode_result);
            curl_close($ch);
            if ($result->result){

               $data['user_list'] = $result; 
               $data['catgory']   = $name;
               $this->session->set_flashdata('success', $result->message); 
               $this->load->view('admin/user/list' ,$data); 

            }else{
               
               $this->session->set_flashdata('error', $result->message);   
               $this->load->view('admin/user/list');
            } 


        }else{

          $this->load->view('admin/user/list');
        }
   }

   /*==============Register teacher list in activity =============*/

   function registerteacher()
   {
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/teacherList");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken    
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);

        //print_r($server_output); die;
        $data['teachers'] = json_decode($server_output);
        $this->load->view('admin/teacher/list' ,$data); 
   }

   /*=====================Take Attendace of Teacher===================*/

   function teacherAttendace(){

     $this->input->post('w_session');
     $this->input->post('teacherId');

     if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $w_session   = $this->input->post('w_session');
            $teacherId   = $this->input->post('teacherId');
            
            if($w_session){ $ww_session = $this->input->post('w_session'); }
            if($teacherId){ $teacher_Id = $this->input->post('teacherId'); }

            $teacherIdsArray = array((int)$teacher_Id);

            $data   = array( 'session'  => $w_session,'teacherIds' => $teacherIdsArray );
            $json = json_encode($data);

            //print_r($json); die;

            $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/teacherAttendence');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'loginToken:'.$this->loginToken)
            );
            $encode_result  = curl_exec($ch);
            $result         = json_decode($encode_result);
            curl_close($ch);
            echo $encode_result; die; 
        
        }else{

          $this->load->view('admin/teacher/list');
        }
   }
/*=====================Take Multiple Attendace===================*/

  function teacherMultipleAttendace(){

     $mw_session   = $this->input->post('mw_session');

     $teacherIds   = $this->input->post('teacherId');

     
 
        $numArray = array_map('intval', $teacherIds);

        $info = array(
                      'session'      => $mw_session,
                      'teacherIds'   => $numArray 
                       );
 
        $data_string = json_encode($info);
        
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/teacherAttendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        echo $result1;
        die();
       

        
     } 

/********************/
  
  function getteacherbyDateAndSession(){
        
        
        
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $date  = date_create($this->input->post('date'));
            $date_format = date_format($date,"Y-m-d");
            $session  = $this->input->post('w_session'); 

            $body = '{}';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/report/teacherAttendence");
            curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
            curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            $headers = [
                
                'Content-Type: application/json; charset=utf-8',
                'loginToken:'.$this->loginToken,
                'Date:'.$date_format,    
                'Session:'.$session    
               
            ];

            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $server_output = curl_exec ($ch);
            curl_close ($ch);
            $data['teacher_data'] =   json_decode($server_output);
            $this->load->view('admin/teacher/attendancelist' ,$data);

        }else{

            $this->load->view('admin/teacher/attendancelist');

        }
        

  }        
 
}	