<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//require_once('main.php');

class Registrations extends CI_Controller {

	
	function index(){
        
              if ($_SERVER['REQUEST_METHOD'] == 'POST'){
              
        $activityId = $this->input->post('activityId');
        $phaseId    = $this->input->post('phaseId');
        $locationId = $this->input->post('locationId');
        $classId    = $this->input->post('classId');
        $schoolId   = $this->input->post('schoolId'); 
        
        $fname = $this->input->post('fname');
        
        $lname = $this->input->post('lname'); 
        
         
        
        $studentName = $fname." ".$lname;      
        if(!empty($activityId) && !empty($phaseId) && !empty($locationId) && !empty($studentName)){
        
             $data = array(

                                   "studentName"      => $studentName,
                                   "activityId"       => (int)$activityId,
                                   "phaseId"          => (int)$phaseId,
                                   "locationId"       => (int)$locationId,
                                   "schoolId"         => (int)$schoolId,
                                   "class"            => (int)$classId
                                   
                                
                            );

        $data_string = json_encode($data);
        //print_r($data_string); die;
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/registerWithName');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
            )
        );
        
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        if($result->result) {
            $data['msg_success'] = $result->message; 
            $this->load->view('registration',$data);
        }else{
        
            $data['msg_success'] = $result->message; 
            $this->load->view('registration',$data);
        }
        
        }else{
        
            $this->load->view('registration');        
        }
              
              }else{
                  $this->load->view('registration');
              }
	}
	
}	