<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Rco extends Main {

  public $loginToken=0;

  function __construct()
  {
        parent::__construct('rco');
        $this->loginToken = $this->session->userdata("tokenid");
  }

	public function index()
	{
     if($this->session->userdata("role")=="rco"){
           
           $data['location'] = '';
           $this->load->view('rco/list' ,$data);

      }else{

           $this->load->view('home/page-login');
        
      }
  }

  public function registerpage(){
     
     if($this->session->userdata("role")=="rco"){
           
           $this->load->view('rco/registerstudent');
           

      }else{

           $this->load->view('home/login');
        
      } 
    
  }

  /*************** for add student view*********************************/

  public function addstudent(){
     
     if($this->session->userdata("role")=="rco"){
           
           $this->load->view('rco/addstudent');
           

      }else{

           $this->load->view('home/login');
        
      } 
    
  }

/*******************STUDENT REGISTER TO EVENT **************************/

  public function schoollist(){

        $society = $this->input->post('society');
        //echo $society; die;
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/school/list");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'society:'.$society,
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output ;

    }

/*************************tranee attendace************************************/

function Trainee_attendance(){

 $this->load->view('rco/trainee_attendance');
 
}

/****************Get entire student list based on activity details***********************/

  function entireStudentListBasedDetail(){
         
        if($_SERVER['REQUEST_METHOD'] == 'POST'){  

           $data = array(

               "activityId"    => $this->input->post('activityId'),
               "phaseId"       => $this->input->post('phaseId'),
               "locationId"    => $this->input->post('locationId')
               
          );

          $data_string = json_encode($data);
          $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/registrationList');
          curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
          curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
              'Content-Type: application/json',
              'loginToken:'.$this->loginToken)
          );

          $result = curl_exec($ch);
          curl_close($ch);
          echo $result; die();   

        }else{

          $this->load->view('rco/entirestudentlist');   
        }
    } 
/***********EDIT STUDENT REGISTRATION PROFILE *****************/

  function editregistration(){

      $data['studentId']   = $_GET['id'];
      $data['eventId']     = $_GET['eventId'];
      $data['studentName'] = $_GET['name'];
      $data['schoolName']  = $_GET['schoolName'];
      $data['class']       = $_GET['class'];
      $data['section']     = $_GET['section'];
      $data['gender']      = $_GET['gender'];
      $data['registrationId'] = $_GET['registrationId'];
      $data['campId']      = $_GET['campId']; 
      $data['activityId']  = $_GET['activityId'];
      $data['locationId']  = $_GET['locationId'];
      $data['phaseId']     = $_GET['phaseId']; 
      $data['campName']         = $_GET['campName']; 
      $data['phaseName']        = $_GET['phaseName']; 
      $data['locationName']     = $_GET['locationName']; 
      $data['activityName']     = $_GET['activityName']; 

      $this->load->view('rco/s_profile' ,$data);
  }

/*****************STUDENT REGISTRATION PROFILE DETAIL*************/

  function editStudentProfile(){

    $data['studentId']      = $this->input->post('studentId');
    $data['studentName']    = $this->input->post('studentName');
    $data['registrationId'] = $this->input->post('registrationId');
    $data['locationId']     = $this->input->post('locationId');
    $data['phaseId']        = $this->input->post('phaseId');
    $data['activityId']     = $this->input->post('activityId');
    $data['camp_id']         = $this->input->post('camp_id');

    $data['phaseName']       = $this->input->post('phaseName');
    $data['locationName']    = $this->input->post('locationName');
    $data['activityName']    = $this->input->post('activityName');

    $this->load->view('rco/edit_registration' ,$data);  
  }

/*****************EDIT STUDENT REGISTRATION PROFILE*************/     

  function edit_profile(){

     if($_SERVER['REQUEST_METHOD'] == 'POST'){  

           $data = array(

               "activityId"    => $this->input->post('activityId'),
               "phaseId"       => $this->input->post('phaseId'),
               "locationId"    => $this->input->post('locationId'),
               "studentId"         => $this->input->post('studentId'),
               "registrationId"    => $this->input->post('registrationId')
               
          );

          $data_string = json_encode($data);
          $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/updateRegistration');
          curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
          curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
              'Content-Type: application/json',
              'loginToken:'.$this->loginToken)
          );

          $result = curl_exec($ch);
          $responce = json_decode($result);
          curl_close($ch);
          if($responce->result){
                
                $this->session->set_flashdata('success', $responce->message); 
                redirect('rco/entireStudentListBasedDetail');
          }else{
                
                $this->session->set_flashdata('error', $responce->message); 
                redirect('rco/entireStudentListBasedDetail');    
          }
          
          $this->load->view('rco/entirestudentlist');   
        }else{

          $this->load->view('rco/entirestudentlist');   
        }

  }
}	