<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Activity extends Main {
    public $loginToken=0;
    
    function __construct()
    {
        parent::__construct('activity');
        $this->loginToken = $this->session->userdata("tokenid");
    }

	public function index()
	{
		$this->load->view('home/index');
	}
	public function activitylist(){
        $body = '{}';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/list");
		//curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
		curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$headers = [
		    
		    'Content-Type: application/json; charset=utf-8',
		   
		];

		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$server_output = curl_exec ($ch);

		curl_close ($ch);

		$data['activity'] = $server_output ;

         $this->load->view('activity/list' ,$data);

    }

/********************Activity list by camp id*****************/

    public function ActivityListBycampId(){

         $campId = $this->input->post('campId');
         
         $ch = curl_init();
         curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/listByCamp");
         //curl_setopt($ch, CURLOPT_POST, 1);
         curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        // curl_setopt($ch, CURLOPT_POSTFIELDS,  $campId);  //Post Fields
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

         $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'campId: '.$campId
         ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);

         echo $server_output;  die;
    }

/*******************phase list********************************/

    public function phaseListbasedActivity(){

        $activityId = $this->input->post('activityId');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/phase");
        //curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        //curl_setopt($ch, CURLOPT_POSTFIELDS,  $activityId);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'activityId: '.$activityId
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);

        echo $server_output; die();

    }
 /***************Phase List based on activity*****************************/

    function getlocationByactivityIdAndphaseId(){
        
        $activityId = $this->input->post('activityId');
        $phaseId    = $this->input->post('phaseId');

        $ch = curl_init();
        //$getdata = json_encode($vars);
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/location");
        //curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        //curl_setopt($ch, CURLOPT_POSTFIELDS,  $getdata);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'activityId: '.$activityId,
            'phaseId: '.$phaseId
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);

        echo $server_output; die(); 
        

    }
    
}