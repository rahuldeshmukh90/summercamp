<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Trainee extends Main {

  public $loginToken=0;

  function __construct()
  {
        parent::__construct('rco');
        $this->loginToken = $this->session->userdata("tokenid");
  }

  public function index()
  {
     if($this->session->userdata("role")=="trainer"){
           
           
           $this->load->view('trainee/list');

      }else{

           $this->load->view('home/page-login');
        
      }
  }

  /*******GET ALL STUDENT LIST***************/

 public function schoollist(){

        $activityId = $this->input->post('activityId');
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/studentListWRTEventIdForAttendence");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'activityId:'.$activityId,
            'loginToken:'.$this->loginToken
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output ;

    }

  /******************Take Attendace (FOR TRAINEE )*************************/

    public function takeAttendanceByajax(){
  
 
        $studentId   = $this->input->post('studentId');
        $eventId    = $this->input->post('eventId');

       if (!empty($taineeId) && !empty($eventId)){
        
        $data  = array(
                        "eventId"  => (int)$eventId,
                        "studentIds" => array((int)$studentId)
                      );
        
        $data_string = json_encode($data);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/attendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        
        echo $result1; die();
        
        }else{

          redirect(site_url('cro/traineeAttendance'));  
        }    
        
    }  

   /***********take multiple attendace*****************/
    
    function multipleattendaceUpdate(){

     $eventId   = $this->input->post('eventId');
     $trainerIds = $this->input->post('attendance');

        $numArray = array_map('intval', $trainerIds);

        $info = array(
                      'eventId'      => (int)$eventId,
                      'studentIds'   => $numArray 
                       );
 //print_r($info); die; 
        $data_string = json_encode($info);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/attendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        echo $result1;
        die();
       

        
    }   
    

  
} 