<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Vendor extends Main {

  public $loginToken=0;

  function __construct()
  {
        parent::__construct('vendor');
        $this->loginToken = $this->session->userdata("tokenid");
  }

	public function index()
	{
     if($this->session->userdata("role")=="vendor"){
         
           $this->load->view('vendor/list');

      }else{
 
        $this->load->view('home/login');
        
      }

	}
  /*===================Get all activity list assigned to a vendor====================*/

  public function Assigned_activity(){
    //echo $this->loginToken; die;
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/vendor/activityAssigned");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        $result = json_decode($server_output);
        if($result->result){

              $data['asignActivity'] = $result;
              $this->load->view('vendor/index' ,$data);   
        }
  }

  /*=========================Add a trainer and assign them to a activity====================*/

  

  function addTainee(){
  
        
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
       
        $name           = $this->input->post('name');
        $userName       = $this->input->post('userName');
        $password       = $this->input->post('password');
        $activityId     = $this->input->post('activityId');

        if(!empty($activityId)){
              

        $data  = array(
                        "name"       => $name,
                        "userName"   => $userName,
                        "password"   => $password,
                        "activityId" => $activityId,
                      );
        //print_r($data); die;
        $data_string = json_encode($data);
        
        //print_r($data_string); 

        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/trainer/add');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        //execute post
        $result1 = curl_exec($ch);

        //echo $result1; 
        $result = json_decode($result1);
        curl_close($ch);
        //print_r($result); die();
        if($result->result) {

              $data['msg_success'] = $result->message;
              $this->session->set_flashdata('success', 'Add Trainee Successfully.'); 
              redirect('vendor/addTainee');
        }else{

            $data['msg_success'] = "error";
            $this->session->set_flashdata('error', 'Trainee is not added.'); 
            redirect('vendor/addTainee');
        }

    }else{
             
            redirect('vendor/addTainee');
    }
    }else{

      $this->load->view('vendor/addtainee');

    }    
        
  }

 /*==================CHECK USERNAME==================================*/

  function checkusername(){

     if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $username = $this->input->post('username');   
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/checkUsernameAvailable");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'userName:'.$username)
        );
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output; die;
        
      }else{

       $this->load->view('vendor/addtainee');   
     }  
  }
	
}	