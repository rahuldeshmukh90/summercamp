<?php
/**
 * @author panacea-soft
 */
class Main extends CI_Controller
{
	function __construct($module_name = null)
	{
		//$this->load->library('session');
		parent::__construct();
		//If user has no permission, redirect to login.
		
		if (!$this->user->is_logged_in()){

			redirect(site_url('home/login'));
		}else{
           
                   $_SERVER['PHP_SELF'];
        }
		
		// $logged_in_user_info = $this->user->get_logged_in_user_info();
		// $data['user_info'] = $logged_in_user_info;
                // $this->load->vars($data);
	}
	
}
?>