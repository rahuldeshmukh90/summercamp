<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		if($this->user->is_logged_in()){

		   if($this->session->userdata("role")=="admin"){
                      $this->load->view('admin/dashboard');                 
		   }elseif($this->session->userdata("role")=="teacher"){
                      $this->load->view('home/index');  
           }elseif($this->session->userdata("role")=="school"){
                      redirect('school');  
           }elseif($this->session->userdata("role")=="rco"){
                      redirect('rco');
           }elseif($this->session->userdata("role")=="cro"){
                      redirect('cro');
           }elseif($this->session->userdata("role")=="trainer"){
           	          redirect('trainee');
           }elseif($this->session->userdata("role")=="vendor") {
           	          redirect('vendor');
           }elseif($this->session->userdata("role")=="secretary") {
           	          redirect('secretary');
           }else{
               
               redirect('login');
           }
              
           
		}
    }
    
    function Dashboard(){

       $this->load->view('admin/dashboard');
	}
    public function login(){

         if ($_SERVER['REQUEST_METHOD'] == 'POST'){
         	 
         	 $username = $this->input->post('username');
         	 $pass     = $this->input->post('password');
         	 $vars = array(        
						 "userName" => $username,
						 "digest"   => $pass
					    );
         	 
            $data_string = json_encode($vars);  
            $ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/login");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);  //Post Fields
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			$headers = [
    
                        'Content-Type: application/json; charset=utf-8',
                       ]; 

			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

			$server_output = curl_exec ($ch);
            $checkdata =  json_decode($server_output);

			if($checkdata->result){
                
                //echo $this->session->userdata("user_id"); die();    
				if($this->user->userlogin($checkdata->result,$checkdata->id,$checkdata->loginToken,$checkdata->role,$checkdata->dashboard)){
                 
                  if($this->user->is_logged_in()){
                    
                    if ($this->session->userdata("role")!="admin"){

				        if($this->session->userdata("role")=="teacher"){
				            
				                            //$this->session->set_flashdata('success', 'Login successfully.'); 
			                                $this->load->view('home/index');
                        }elseif($this->session->userdata("role")=="school"){
                                            //$this->session->set_flashdata('success', 'Login successfully.'); 
                                            redirect('school'); 
			                                //$this->load->view('school/add'); 
				        }elseif($this->session->userdata("role")=="rco"){
                            
                                           //$this->session->set_flashdata('success', 'Login successfully.'); 
                                           redirect('rco');
                        }elseif($this->session->userdata("role")=="cro"){
                        	                //$this->session->set_flashdata('success', 'Login successfully.'); 
                                            redirect('cro');
				        }elseif($this->session->userdata("role")=="vendor"){
                                            //$this->session->set_flashdata('success', 'Login successfully.'); 
                                            redirect('vendor'); 
				        }elseif($this->session->userdata("role")=="trainer"){
                                            redirect('trainee'); 

				        }elseif($this->session->userdata("role")=="secretary"){
                                            redirect('secretary');
				        }else{
                                $this->session->set_flashdata('error', $checkdata->message);
                                redirect(site_url());   
				        } 
				    
				    }else{
				        	   
		                //$this->session->set_flashdata('success', 'Login successfully.'); 
	                    $this->load->view('admin/dashboard');
				    }  
                    

                  }else{
  
                    $this->session->set_flashdata('error', 'There is some Problem , Please Try again later .'); 
			        $this->load->view('home/index'); 
                  }
                  

				}else{
                  
	                $this->session->set_flashdata('error', 'There is some Problem , Please Try again later .'); 
				    $this->load->view('home/index'); 
				}
                
				
			}else{
				//echo $checkdata->message;
				    $this->session->set_flashdata('error', $checkdata->message); 
			        //$this->load->view('home/login');
			        //$this->load->view('home/page-login'); 
			        redirect('home/login');
				
			}
		    
			curl_close ($ch);
			
         }else{
            
            //$this->load->view('home/login'); 
              $this->load->view('home/page-login'); 
         }  
        
    }

    function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url(''));
	}
    
}