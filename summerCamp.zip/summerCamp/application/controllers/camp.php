<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Camp extends Main {

  public $loginToken=0;

  function __construct()
  {
        parent::__construct('camp');
        $this->loginToken = $this->session->userdata("tokenid");
  }

	public function index()
	{
		$this->load->view('home/index');
	}
	function getcamplist(){
        
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/camp/list");
       // curl_setopt($ch, CURLOPT_POST, 0);
       // curl_setopt($ch, CURLOPT_POSTFIELDS);  //Post Fields
	      curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
		    curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);

        curl_close ($ch);

        echo $server_output ;
	}
}	