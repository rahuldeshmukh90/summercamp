<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once('main.php');
// Code written by TangleSkills

class Qrimages extends Main {
    
    public $loginToken=0;
    public $loginRole=0;

	public function __construct()
    {
          parent::__construct();
		  $this->load->helper('url');
		  $this->loginRole = $this->session->userdata("role");
    }

    public function get_file_dir() {
	    global $argv;
	    $dir = dirname(getcwd() . '/' . $argv[0]);
	    $curDir = getcwd();
	    chdir($dir);
	    $dir = getcwd();
	    chdir($curDir);
	    return $dir; 
	}
    public function sleeptimeZone()
    {
    	sleep(5);
    	$files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
        foreach($files as $file){ // iterate files
		  if(is_file($file))
		    unlink($file); // delete file
		}
    }
	public function index()
	{
		
        if($this->loginRole=="cro"){
        $files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
        foreach($files as $file){ // iterate files
		  if(is_file($file))
		    unlink($file); // delete file
		}
        if (!empty($_GET['id']) || !empty($_GET['eventId'])) {
		
		    $data['id']        = $_GET['id']; 
			$data['eventId']   = $_GET['eventId'];
			$data['name']       = $_GET['name'];

			$data['img_url'] = "";
			if($this->input->post('action') && $this->input->post('action') == "generate_qrcode")
			{
				
				$this->load->library('ciqrcode');
				$qr_image=rand().'.png';
				$params['data'] = $this->input->post('qr_text');
				$params['level'] = 'H';
				$params['size'] = 8;
				$params['savename'] =FCPATH."uploads/qr_image/".$qr_image;
				if($this->ciqrcode->generate($params))
				{
					$data['img_url']=$qr_image;	
				}
			}
            // $data['action'] = $this->input->post('action');
            $this->load->view('cro/qrcode',$data);

		}else{

            $this->load->view('cro/attendence'); 
		}   	
        
        }elseif($this->loginRole=="teacher"){
        $files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
        foreach($files as $file){ // iterate files
		  if(is_file($file))
		    unlink($file); // delete file
		}
		if (!empty($_GET['id']) || !empty($_GET['eventId'])) {
		  
		    $data['id']        = $_GET['id']; 
			$data['eventId']   = $_GET['eventId'];
			$data['activity']  = $_GET['activity'];

			$data['img_url'] = "";
			if($this->input->post('action') && $this->input->post('action') == "generate_qrcode")
			{
				
				$this->load->library('ciqrcode');
				$qr_image=rand().'.png';
				$params['data'] = $this->input->post('qr_text');
				$params['level'] = 'H';
				$params['size'] = 8;
				$params['savename'] =FCPATH."uploads/qr_image/".$qr_image;
				if($this->ciqrcode->generate($params))
				{
					$data['img_url']=$qr_image;	
				}
			}
            
            $this->load->view('qrcode',$data);

		}else{

            $this->load->view('student/attendence'); 
		}

        }elseif($this->loginRole=="admin"){
            
		    $files = glob($this->get_file_dir().'/summerCamp/uploads/qr_image/*');
	        foreach($files as $file){ // iterate files
			  if(is_file($file))
			    unlink($file); // delete file
			} 	
	        if (!empty($_GET['id']) ) {
			
			    $data['id']         = $_GET['id']; 
			    $data['name']       = $_GET['name']; 
				$data['gender']     = $_GET['gender'];
				$data['phoneNo']    = $_GET['phoneNo'];
				$data['subject']    = $_GET['subject'];
				$data['schoolName'] = $_GET['schoolName'];
				$data['img_url']    = "";

				if($this->input->post('action') && $this->input->post('action') == "generate_qrcode")
				{
					
					$this->load->library('ciqrcode');
					$qr_image=rand().'.png';
					$params['data'] = $this->input->post('qr_text');
					$params['level'] = 'H';
					$params['size'] = 8;
					$params['savename'] =FCPATH."uploads/qr_image/".$qr_image;
					if($this->ciqrcode->generate($params))
					{
						$data['img_url']=$qr_image;	
					}
				}
	            // $data['action'] = $this->input->post('action');
	            $this->load->view('admin/teacher/qrcode',$data);

			}else{

	            $this->load->view('teacher/list'); 
			}

        }   
		

	    
	}

}
