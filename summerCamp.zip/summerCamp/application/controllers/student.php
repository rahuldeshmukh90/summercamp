<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class Student extends Main {

    private $loginToken=0; 
    function __construct()
    {
        parent::__construct('student');
        $this->loginToken = $this->session->userdata("tokenid");
    }

    function index()
    {
        $this->load->view('home/index');
    }
    function add(){

         if ($_SERVER['REQUEST_METHOD'] == 'POST'){
             
             $name         = $this->input->post('name');
             $schoolId     = $this->input->post('schoolId');
             $standard     = $this->input->post('standard');

             if(!empty($schoolId) && !empty($standard) && !empty($name)) {
                 
             $name = $this->input->post('name');
             $rollNo     = $this->input->post('rollNo');
             $schoolId     = $this->input->post('schoolId');
             $gender     = $this->input->post('gender');
             $standard     = $this->input->post('standard');
             $section     = $this->input->post('section');
             $dob     = $this->input->post('dob');
             $mothersName     = $this->input->post('mothersName');
             $fathersName     = $this->input->post('fathersName');
             $bloodGroup     = $this->input->post('bloodGroup');
             $adhaarId     = $this->input->post('adhaarId');

             $caste     = $this->input->post('caste');
             $primaryContact     = $this->input->post('primaryContact');
             $secondaryContact     = $this->input->post('secondaryContact');

             $address1  = array(

                                'address' => $this->input->post('adress'),
                                'country' => $this->input->post('country'),
                                'district' => $this->input->post('district'),
                                'state' => $this->input->post('state'),
                            ); 
            
            $sec = strtoupper($section);
            $vars = array( 

                         "name"       => $name,
                         "rollNo"     => (int)$rollNo,
                         "schoolId"   => (int)$schoolId,
                         "gender"     => (int)$gender,
                         "standard"   => (int)$standard,
                         "section"    => $sec,
                         "dob"        => $dob,
                         "mothersName"   => $mothersName,
                         "fathersName"   => $fathersName,
                         "bloodGroup"    => $bloodGroup,
                         "adhaarId"      => (int)$adhaarId,
                         "caste"         => $caste,
                         "primaryContact"    => (int)$primaryContact,
                         "secondaryContact"  => (int)$secondaryContact,
                         "address"       => $address1,
                         
                        );
                        
             

             $data_string = json_encode($vars); 

        
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/student/add');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string),
            'loginToken:'.$this->loginToken)
        );

        //execute post
        $result1 = curl_exec($ch);

            $data['server_output'] = $result1 ; 

            $this->session->set_flashdata('success', 'Student Added Successfully.');
            redirect('student/add');
            exit();
        }else{

            $this->session->set_flashdata('success', 'Plsease Fill All Fields.');
            redirect('student/add');
        }

         }else{
            
            $this->load->view('student/add');
         }

    }

    public function schoollist(){

        $society = $this->input->post('society');
        //echo $society; die;
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/school/list");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'society:'.$society,
           
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output ;

    }
    
    public function registerStudentforEvent(){
        
        $activityId = $this->input->post('activityId');
        $phaseId    = $this->input->post('phaseId');
        $locationId = $this->input->post('locationId');
        $studentId  = $this->input->post('studentId');     
        if(!empty($activityId) && !empty($phaseId) && !empty($locationId) && !empty($studentId)){
        if(!empty($studentId)){
             
            $checkProfile   = $this->studentprofileCompleteOrNot($studentId);
            
            $check          = json_decode($checkProfile);
           
            if($check->complete){


                 /******check data***************/
                 //(isset($check->studentDetails->name)?$check->studentDetails->name:'') 
                 /***********STUIDENT DETAIL****************/ 
                 // $stdname          = $check->studentDetails->name;
                 // $stdrollNo        = $check->studentDetails->rollNo;
                 // $stdschoolId      = $check->studentDetails->schoolId;
                 // $stdgender        = $check->studentDetails->gender;
                 // $stdstandard      = $check->studentDetails->standard;
                 // $stdsection       = $check->studentDetails->section;
                 // $stddob           = $check->studentDetails->dob;
                 // $stdmothersName   = $check->studentDetails->mothersName;
                 // $stdfathersName   = $check->studentDetails->fathersName;
                 // $stdbloodGroup    = $check->studentDetails->bloodGroup;
                 // $stdadhaarId      = $check->studentDetails->adhaarId;
                 // $stdcaste             = $check->studentDetails->caste;
                 // $stdprimaryContact    = $check->studentDetails->primaryContact;
                 // $stdsecondaryContact  = $check->studentDetails->secondaryContact;
                 /*************ADDRESS SECTION*****************/
                 // $stdaddress           = $check->studentDetails->address->address;
                 // $stdcountry           = $check->studentDetails->address->country;
                 // $stddistrict          = $check->studentDetails->address->district;
                 // $stdstate             = $check->studentDetails->address->state;
                 /***************ID BASED NAME****************/
                // $stdsecondaryContact  = $check->studentDetails->schoolName;
                 /*****************MALE/FEMALE*****************/
                 // if($stdgender=="MALE"){
                 //      $gender = 1;
                 // }else if($stdgender=="FEMALE"){
                 //      $gender = 2;  
                 // }else{
                 //      $gender = 0;
                 // }
                 
                 // $addess = array(

                 //         "address"     => $stdaddress,
                 //         "district"    => $stddistrict,
                 //         "state"       => $stdstate,
                 //         "country"     => $stdcountry  

                 //        );
                 
                 // $studentDetail = array( 

                 //         "name"       => $stdname,
                 //         "rollNo"     => (int)$stdrollNo,
                 //         "schoolId"   => (int)$stdschoolId,
                 //         "gender"     => (int)$gender,
                 //         "standard"   => (int)$stdstandard,
                 //         "section"    => $stdsection,
                 //         "dob"        => $stddob,
                 //         "mothersName"   => $stdmothersName,
                 //         "fathersName"   => $stdfathersName,
                 //         "bloodGroup"    => $stdbloodGroup,
                 //         "adhaarId"      => (int)$stdadhaarId,
                 //         "caste"         => $stdcaste,
                 //         "primaryContact"    => $stdprimaryContact,
                 //         "address"       => $addess,
                 //         "secondaryContact"  => $stdsecondaryContact
                         
                 //        );
                 

                $data = array(

                                   "studentId"      => $studentId,
                                   "activityId"     => $activityId,
                                   "phaseId"        => $phaseId,
                                   "locationId"     => $locationId
                                   //"studentDetails" => $studentDetail
                            );

        $data_string = json_encode($data);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/register');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string),
            'loginToken:'.$this->loginToken)
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        if($result->result) {
            $data['msg_success'] = $result->message;
            $this->load->view('home/index',$data);
        }else{
            
            $data['msg_success'] = "error";
            $this->load->view('home/index'); 
        } 
                    
        }else{
                 
                $data['allids'] = array(

                           "studentId"      => $studentId,
                           "activityId"     => $activityId,
                           "phaseId"        => $phaseId,
                           "locationId"     => $locationId,
                    );
                 
                $data['stdinfo'] = json_decode($checkProfile);
                $this->load->view('student/edit' ,$data);
            }
        } 
    }else{ 
            redirect(site_url('dashboard'));
    }    
}
    /**********ADD UPDATED STUDENT PROFILE FOR ACTIVITY************/


    function updateprofileAddintoActivity(){

                 /***********STUIDENT DETAIL****************/ 
                 $stdname          = $this->input->post('name');
                 $stdrollNo        = $this->input->post('rollNo'); 
                 $stdschoolId      = $this->input->post('schoolId'); ;
                 $stdgender        = $this->input->post('gender'); 
                 $stdstandard      = $this->input->post('standard'); 
                 $stdsection       = $this->input->post('section'); 
                 $stddob           = $this->input->post('dob'); 
                 $stdmothersName   = $this->input->post('mothersName'); 
                 $stdfathersName   = $this->input->post('fathersName'); 
                 $stdbloodGroup    = $this->input->post('bloodGroup'); 
                 $stdadhaarId      = $this->input->post('adhaarId'); ;
                 $stdcaste             = $this->input->post('caste'); 
                 $stdprimaryContact    = $this->input->post('primaryContact'); 
                 $stdsecondaryContact  = $this->input->post('secondaryContact'); 
                 /*************ADDRESS SECTION*****************/
                 $stdaddress           = $this->input->post('adress'); 
                 $stdcountry           = $this->input->post('country'); 
                 $stddistrict          = $this->input->post('district'); 
                 $stdstate             = $this->input->post('state'); 
                 /*************GET ALL IDS*********************/
                 $activityId           = $this->input->post('activityId'); 
                 $studentId            = $this->input->post('studentId'); 
                 $phaseId              = $this->input->post('phaseId'); 
                 $locationId           = $this->input->post('locationId'); 
                 
                 $addess = array(

                         "address"     => $stdaddress,
                         "district"    => $stddistrict,
                         "state"       => $stdstate,
                         "country"     => $stdcountry  

                        );

                 $studentDetail = array( 

                         "name"       => $stdname,
                         "rollNo"     => (int)$stdrollNo,
                         "schoolId"   => (int)$stdschoolId,
                         "gender"     => (int)$stdgender,
                         "standard"   => (int)$stdstandard,
                         "section"    => $stdsection,
                         "dob"        => $stddob,
                         "mothersName"   => $stdmothersName,
                         "fathersName"   => $stdfathersName,
                         "bloodGroup"    => $stdbloodGroup,
                         "adhaarId"      => (int)$stdadhaarId,
                         "caste"         => $stdcaste,
                         "primaryContact" => $stdprimaryContact,
                         "address"       => $addess,
                         "secondaryContact"  => $stdsecondaryContact
                         
                        );

                 $data = array(

                           "studentId"      => (int)$studentId,
                           "activityId"     => (int)$activityId,
                           "phaseId"        => (int)$phaseId,
                           "studentDetails" => $studentDetail, 
                           "locationId"     => (int)$locationId
                           
                           );
                    
                    $data_string = json_encode($data);
                    $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/register');
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'loginToken:'.$this->loginToken)
                    );
                    $result1 = curl_exec($ch);
                    $result = json_decode($result1);
                    curl_close($ch);
                    if($result->result) {
                        $data['msg_success'] = $result->message;
                        $this->load->view('home/index',$data);
                    }else{
                        
                        $data['msg_success'] = "error";
                        $this->load->view('home/index'); 
                    }
    }
    public function getstudentInfoByid($studentId){

        $studentId1 = $studentId;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/student/get");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            'Content-Type: application/json; charset=utf-8',
            'id: '.$studentId1,
            'loginToken:'.$this->loginToken
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        return $server_output;

    }

    /*********************for search student**************************/

    public function SearchstudentByschoolAndclass(){

        $data = array(

               "schoolId" => $this->input->post('schoolId'),
               "class"    =>  $this->input->post('classId')
        );
        $data_string = json_encode($data);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/student/search');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string),
            'loginToken:'.$this->loginToken)
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result; die();

    }

    function attendence(){

      $this->load->view('student/attendence');

    }

    function studentsRegisteredParticularActivity(){
         
        $data = array(

               "activityId"    => $this->input->post('activityId'),
               "phaseId"       => $this->input->post('phaseId'),
               "locationId"    => $this->input->post('locationId')
               
        );

        $data_string = json_encode($data);

        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/studentList');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );

        $result = curl_exec($ch);
        curl_close($ch);
        echo $result; die();   
    }

    function classlistbasedOnActivity(){


        $activity = $this->input->post('activityId');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/assignedClass");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'activityId: '.$activity
         ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output; die;

    }
/***********NOT REGISTERED STUDENT LIST*************************/
    function notRegisteredStudent_listActivity(){

       $loginToken = $this->session->userdata("tokenid"); 

        $data = array(

               "activityId"  => (int)$this->input->post('activityId'),
               "phaseId"     => (int)$this->input->post('phaseId'),
               "locationId"  => (int)$this->input->post('locationId'),
               "schoolId"    => (int)$this->input->post('schoolId'),
               "class"       => (int)$this->input->post('classId')
               
        );
        
        $data_string = json_encode($data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/studentListNotRegistered");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'POST' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $data_string);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'loginToken:'.$this->loginToken
         ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output; die;


    }

    /***********CHECK STUDENT PROFILE IS COMPLETE OR NOT*******************/

    function studentprofileCompleteOrNot($studentId){

        $studentId1 = $studentId;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/student/checkProfile");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            'Content-Type: application/json; charset=utf-8',
            'id: '.$studentId1,
            'loginToken: '.$this->loginToken
         ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        return $server_output; 

    } 
    /***********take multiple attendace*****************/
    function multipleattendaceUpdate(){

     $activityId = $this->input->post('activityId');

     $studentId = $this->input->post('attendance');

        $numArray = array_map('intval', $studentId);

        $info = array(
                      'eventId'      => (int)$activityId,
                      'studentIds'   => $numArray 
                       );
    
        $data_string = json_encode($info);
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/activity/attendence');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        $result1 = curl_exec($ch);
        $result = json_decode($result1);
        curl_close($ch);
        echo $result1;
        die();
       

        
     }

    /**********************Schoollist-by-society***********************/
    public function schoollistbySociety(){

        $society = $this->input->post('society');
        //echo $society; die;
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/school/listBasedOnToken");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            
            'Content-Type: application/json; charset=utf-8',
            'society:'.$society,
            'loginToken:'.$this->loginToken 
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        echo $server_output ;

    } 
     
}