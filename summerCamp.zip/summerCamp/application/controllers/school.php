<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('main.php');

class School extends Main {

  public $loginToken=0;

  function __construct()
  {
        parent::__construct('school');
        $this->loginToken = $this->session->userdata("tokenid");
  }

	public function index()
	{
     if($this->session->userdata("role")=="school"){
           
           $this->load->view('school/teacher_list');

      }else{

        $this->load->view('home/login');
        
      }

		
	}

  /*************GET ALL ACTIVITY LIST**********************/

  public function getActivity(){
     
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/event/list");
       // curl_setopt($ch, CURLOPT_POST, 0);
       // curl_setopt($ch, CURLOPT_POSTFIELDS);  //Post Fields
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $server_output = curl_exec ($ch);
        //print_r($server_output); die;
        curl_close ($ch);
        $result = json_decode($server_output);
        if($result->result){
              $data['activity'] = $result;        
              $this->session->set_flashdata('success', $result->message); 
              $this->load->view('activity/list' ,$data);  
        }else{

              $this->session->set_flashdata('error', $result->message); 
              $this->load->view('activity/list');  
        }
        
}

/***********************ADD TEACHER INTO SCHOOL***************************/


function addteacher(){
  
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        if($_FILES['imageUrl']['tmp_name']){
          $base64_imgData = base64_encode(file_get_contents($_FILES['imageUrl']['tmp_name']));        
        }    
        if($this->input->post('name')){ $data['name'] = $this->input->post('name');}   
        if($this->input->post('gender')){ $data['gender'] = $this->input->post('gender');  }   
        if($this->input->post('phoneNo')){ $data['phoneNo'] = $this->input->post('phoneNo');}   
        if($this->input->post('emailId')){ $data['emailId'] = $this->input->post('emailId');}
        if($this->input->post('joinedYear')){ $data['joinedYear'] = $this->input->post('joinedYear');  }   
        if($this->input->post('caste')){ $data['caste'] = $this->input->post('caste'); }    
        if($this->input->post('aadharNo')){ $data['aadharNo'] = $this->input->post('aadharNo'); }   
        if($base64_imgData){ $data['imageUrl'] = $base64_imgData;}   
        
        $data_string = json_encode($data);

       // print_r($data_string); die;    
        $ch = curl_init('http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/teacher/add');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        //execute post
        $result1 = curl_exec($ch);

        //echo $result1; 
        $result = json_decode($result1);
        curl_close($ch);
        if($result->result){

              $data['msg_success'] = $result->message;
              $this->session->set_flashdata('success', $result->message); 
              redirect('school/addteacher');
        }else{

            $data['msg_success'] = $result->message;
            $this->session->set_flashdata('success', $result->message); 
            redirect('school/addteacher');
        }

    }else{

       $this->load->view('school/add');

    }    
        
  }

/******************FOR TEACHER LIST***************************/


  public function teacherList(){
     
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/teacher/list");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        $data['teacher'] = json_decode($server_output);
        $this->load->view('school/teacher_list' ,$data);
}

/******************FOR TEACHER LIST WITH DETAIL***************************/

  public function teacherListWITHdetail(){
     
        $body = '{}';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://telanganaschoolapp-env.us-west-2.elasticbeanstalk.com/govt/teacher/detailedList");
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($ch, CURLOPT_POSTFIELDS,  $body);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'loginToken:'.$this->loginToken)
        );
        $server_output = curl_exec ($ch);
        curl_close ($ch);
        $data['teacher'] = json_decode($server_output);
        $this->load->view('school/teacher_list' ,$data);
  }

	
}	